"use client";  // ✅ Ensures this runs on the client



export default function SettingPage() {



  return (
    <>
    <h1>This is setting Page</h1>
    <span>Will update this page leter</span>
    </>
  );
}
