import CalendarComponent from "../components/Calendar";

export default function TodoPage() {
  return <CalendarComponent />;
}
