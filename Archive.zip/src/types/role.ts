// types/roles.ts
export enum UserRole {
    ADMIN = "admin",
    USER = "user",
    MANAGER = "manager",
  }
  